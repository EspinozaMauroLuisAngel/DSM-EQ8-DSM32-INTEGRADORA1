// Una variable a otra variable.
var a;
a = 7;
var b;

// Practica - Asigna el contenido de a a la variable b.
b = a;


