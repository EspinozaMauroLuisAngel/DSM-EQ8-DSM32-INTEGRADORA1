<?php
$conex = mysqli_connect("localhost","root","","aprendiendo_ando_login"); 
?>
