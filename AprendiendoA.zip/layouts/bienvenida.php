<div> 
    <h2 class="text-center">Bienvenido 
        
        <?php
        include ("../vistas/bd/registro.php");
        $username = ($_POST["username"]);
        echo ($username);
        ?>
        Estas listo para Empezar

    </h2>
</div>


